from django.contrib import admin
from pacman.inventory.models import Item

# Register your models here.
admin.site.register(Item)